import { VoteButtons } from "@/components/VoteButtons";

interface QuestionnaireOptionProps {
  option: string;
  index: number;
  questionNumber?: number;
  isSelected: boolean;
  onVote: () => void;
  disabled: boolean;
}

export const QuestionnaireOption = ({
  option,
  questionNumber,
  isSelected,
  onVote,
  disabled
}: QuestionnaireOptionProps) => {
  return (
    <div 
      className={`flex items-center justify-between gap-4 p-4 ${
        'bg-[#9b87f5]/10'
      } rounded-lg border border-[#D6BCFA] shadow-sm transition-colors hover:border-[#9b87f5]`}
    >
      <div className="flex-1 bg-white p-3 rounded-md">
        {questionNumber && (
          <span className="text-xs font-medium text-gray-500 mb-1 block">
            Pergunta {questionNumber}
          </span>
        )}
        <p className="text-sm text-gray-900 dark:text-gray-100 leading-relaxed">
          {option}
        </p>
      </div>
      <div className="shrink-0">
        <VoteButtons
          isSelected={isSelected}
          onVote={onVote}
          disabled={disabled}
        />
      </div>
    </div>
  );
};