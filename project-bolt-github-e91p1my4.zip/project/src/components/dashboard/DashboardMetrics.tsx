import { Card } from "@/components/ui/card";
import { Heart } from "lucide-react";
import { useFICMetrics } from "@/hooks/useFICMetrics";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const DashboardMetrics = () => {
  const { data: metrics } = useFICMetrics();
  const { data: profile } = useQuery({
    queryKey: ['company-info'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('company_name, company_description, welcome_message, welcome_description, company_logo')
        .single();
      
      if (error) throw error;
      return data;
    },
  });

  const currentFICIndex = metrics?.dailyMetrics[0]?.average_index || 0;
  const previousFICIndex = metrics?.dailyMetrics[1]?.average_index || 0;
  const indexChange = currentFICIndex - previousFICIndex;
  const indexTrend = indexChange >= 0 ? "+" : "";

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card className="p-6 bg-white shadow-lg hover:shadow-xl transition-all duration-300">
        <div className="flex items-center gap-4">
          {profile?.company_logo ? (
            <img
              src={profile.company_logo}
              alt="Logo da empresa"
              className="w-16 h-16 object-contain rounded-lg"
            />
          ) : (
            <div className="p-4 bg-primary/10 rounded-full">
              <Heart className="h-6 w-6 text-primary" />
            </div>
          )}
          <div>
            <h3 className="text-2xl font-bold text-gray-900">{profile?.company_name || "Cocamar"}</h3>
            <p className="text-sm text-gray-500 mt-1">{profile?.company_description || "Sistema de Felicidade Interna do Cooperativismo"}</p>
            <div className="mt-2 flex items-center gap-2">
              <span className="text-lg font-semibold text-primary">
                {currentFICIndex.toFixed(1)}% FIC
              </span>
              <span className="text-sm text-gray-500">
                ({indexTrend}{indexChange.toFixed(1)}% em relação ao dia anterior)
              </span>
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-6 bg-gradient-to-br from-primary/5 to-primary/10 shadow-lg hover:shadow-xl transition-all duration-300">
        <div className="h-full flex flex-col justify-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            {profile?.welcome_message || "Bem-vindo ao Dashboard FIC! 👋"}
          </h2>
          <p className="text-gray-600 leading-relaxed">
            {profile?.welcome_description || "Aqui você pode acompanhar em tempo real os indicadores de felicidade e engajamento da sua cooperativa. Explore os dados e descubra insights valiosos para melhorar a experiência de todos."}
          </p>
        </div>
      </Card>
    </div>
  );
};