import { supabase } from "@/integrations/supabase/client";

const MAX_VOTES_PER_TYPE = 3;

export const submitVotes = async ({
  questionnaireId,
  votes,
  dimension,
  userEmail,
}: {
  questionnaireId: string;
  votes: Array<{ optionType: string; optionNumbers: number[] }>;
  dimension: string;
  userEmail: string;
}) => {
  // Validate vote counts before submission
  for (const { optionType, optionNumbers } of votes) {
    if (optionNumbers.length > MAX_VOTES_PER_TYPE) {
      throw new Error(`Você pode selecionar no máximo ${MAX_VOTES_PER_TYPE} opções por categoria`);
    }
  }

  // Check if user has already voted on this questionnaire
  const { data: existingVotes } = await supabase
    .from('questionnaire_votes')
    .select('id')
    .eq('questionnaire_id', questionnaireId)
    .eq('email', userEmail.toLowerCase());

  if (existingVotes?.length > 0) {
    throw new Error('Você já votou neste questionário');
  }

  // Prepare all vote operations
  const votePromises = [];

  // Register individual votes
  for (const { optionType, optionNumbers } of votes) {
    // Double-check vote count at submission time
    const { data: existingTypeVotes } = await supabase
      .from('questionnaire_votes')
      .select('id')
      .eq('email', userEmail.toLowerCase())
      .eq('option_type', optionType);

    if (existingTypeVotes && existingTypeVotes.length + optionNumbers.length > MAX_VOTES_PER_TYPE) {
      throw new Error(`Você já atingiu o limite de ${MAX_VOTES_PER_TYPE} votos para ${optionType}`);
    }

    for (const optionNumber of optionNumbers) {
      votePromises.push(
        supabase
          .from('questionnaire_votes')
          .insert({
            questionnaire_id: questionnaireId,
            vote_type: 'upvote',
            option_type: optionType,
            option_number: optionNumber,
            email: userEmail.toLowerCase()
          })
      );
    }
  }

  // Execute all promises
  const results = await Promise.all(votePromises);
  
  // Check for errors
  const errors = results.filter(result => result.error);
  if (errors.length > 0) {
    console.error('Errors submitting votes:', errors);
    throw new Error('Erro ao registrar alguns votos');
  }

  // Update questionnaire status
  const { error: updateError } = await supabase
    .from('fic_questionnaires')
    .select('*')
    .eq('id', questionnaireId);

  if (updateError) {
    throw updateError;
  }
  return true;
};