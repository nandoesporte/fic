import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { EmailVerification } from "@/components/voting/EmailVerification";
import { VotingSection } from "@/components/voting/VotingSection";
import { submitVotes } from "@/components/voting/VotingLogic";

type VoteSelection = {
  [key: string]: {
    strengths: number[];
    challenges: number[];
    opportunities: number[];
  };
};

export const QuestionnaireVoting = () => {
  const navigate = useNavigate();
  const [userEmail, setUserEmail] = useState("");
  const [isEmailVerified, setIsEmailVerified] = useState(false);
  const [selections, setSelections] = useState<VoteSelection>({});
  const queryClient = useQueryClient();

  const { data: questionnaires, isLoading } = useQuery({
    queryKey: ['active-questionnaires'],
    queryFn: async () => {
      try {
        // Get questionnaires user hasn't voted on yet
        const { data: userVotes, error: votesError } = await supabase
          .from('questionnaire_votes')
          .select('questionnaire_id')
          .eq('email', userEmail.toLowerCase())
          .eq('vote_type', 'upvote');

        if (votesError) {
          console.error('Error fetching user votes:', votesError);
          throw votesError;
        }

        const votedQuestionnaireIds = new Set(userVotes?.map(v => v.questionnaire_id));

        // Get active questionnaires
        const { data: activeQuestionnaires, error: questionnairesError } = await supabase
          .from('fic_questionnaires')
          .select('*')
          .eq('status', 'active');

        if (questionnairesError) {
          console.error('Error fetching questionnaires:', questionnairesError);
          throw questionnairesError;
        }

        // Filter out voted questionnaires
        const availableQuestionnaires = activeQuestionnaires?.filter(
          q => !votedQuestionnaireIds.has(q.id)
        );

        // Process questionnaires to include only active options
        const processedQuestionnaires = availableQuestionnaires?.map(questionnaire => {
          const processSection = (content: string, statuses: string) => {
            const statusArray = statuses?.split(',') || [];
            return content.split('\n\n')
              .filter((_, index) => statusArray[index] === 'active')
              .join('\n\n');
          };

          return {
            ...questionnaire,
            strengths: processSection(questionnaire.strengths, questionnaire.strengths_statuses),
            challenges: processSection(questionnaire.challenges, questionnaire.challenges_statuses),
            opportunities: processSection(questionnaire.opportunities, questionnaire.opportunities_statuses)
          };
        });

        return processedQuestionnaires || [];
      } catch (error) {
        console.error('Error in questionnaire fetch:', error);
        toast.error('Erro ao carregar questionários. Por favor, tente novamente.');
        throw error;
      }
    },
    enabled: isEmailVerified,
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 10000),
  });

  const submitVotesMutation = useMutation({
    mutationFn: async ({ questionnaireId, votes, dimension }: { 
      questionnaireId: string;
      votes: {
        optionType: string;
        optionNumbers: number[];
      }[];
      dimension: string;
    }) => {
      console.log('Submitting votes:', { questionnaireId, votes, dimension });
      await submitVotes({ questionnaireId, votes, dimension, userEmail });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-questionnaires'] });
      toast.success('Votos registrados com sucesso!');
      setSelections({});
      navigate('/vote-success');
    },
    onError: (error: Error) => {
      console.error('Error in vote submission:', error);
      if (error.message.includes('já votou')) {
        toast.error('Você já votou neste questionário');
      } else if (error.message.includes('limite de')) {
        toast.error(error.message);
      } else {
        toast.error('Erro ao registrar votos. Por favor, tente novamente.');
      }
    },
  });

  const handleVote = (questionnaireId: string, optionType: 'strengths' | 'challenges' | 'opportunities', optionNumber: number) => {
    if (!userEmail) {
      toast.error('Por favor, insira seu email para votar');
      return;
    }

    setSelections(prev => {
      const currentSelections = prev[questionnaireId]?.[optionType] || [];
      const isSelected = currentSelections.includes(optionNumber);

      if (isSelected) {
        return {
          ...prev,
          [questionnaireId]: {
            ...prev[questionnaireId],
            [optionType]: currentSelections.filter(num => num !== optionNumber)
          }
        };
      }

      if (currentSelections.length >= 3) {
        toast.error('Você já selecionou 3 opções nesta seção');
        return prev;
      }

      return {
        ...prev,
        [questionnaireId]: {
          ...prev[questionnaireId],
          [optionType]: [...currentSelections, optionNumber]
        }
      };
    });
  };

  const handleConfirmVotes = async (questionnaireId: string) => {
    const questionnaire = questionnaires?.find(q => q.id === questionnaireId);
    if (!questionnaire) {
      toast.error('Questionário não encontrado');
      return;
    }

    const questionnaireSelections = selections[questionnaireId];
    if (!questionnaireSelections) {
      toast.error('Nenhuma seleção encontrada');
      return;
    }

    const votes = Object.entries(questionnaireSelections).map(([optionType, optionNumbers]) => ({
      optionType,
      optionNumbers,
    }));

    try {
      await submitVotesMutation.mutateAsync({ 
        questionnaireId, 
        votes,
        dimension: questionnaire.dimension 
      });
    } catch (error) {
      console.error('Error confirming votes:', error);
    }
  };

  const handleEmailVerified = (email: string) => {
    setUserEmail(email);
    setIsEmailVerified(true);
  };

  if (!isEmailVerified) {
    return <EmailVerification onVerified={handleEmailVerified} />;
  }

  return (
    <VotingSection
      userEmail={userEmail}
      questionnaires={questionnaires || []}
      isLoading={isLoading}
      selections={selections}
      onVote={handleVote}
      onConfirmVotes={handleConfirmVotes}
    />
  );
};

export default QuestionnaireVoting;