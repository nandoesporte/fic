import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";
import { useNavigate } from "react-router-dom";

export default function Settings() {
  const [loading, setLoading] = useState(false);
  const { session } = useAuth();
  const navigate = useNavigate();
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [companyInfo, setCompanyInfo] = useState({
    name: "Cocamar",
    description: "Sistema de Felicidade Interna do Cooperativismo",
    welcomeMessage: "Bem-vindo ao Dashboard FIC! 👋",
    welcomeDescription: "Aqui você pode acompanhar em tempo real os indicadores de felicidade e engajamento da sua cooperativa. Explore os dados e descubra insights valiosos para melhorar a experiência de todos."
  });
  const [formData, setFormData] = useState({
    cocamarName: "Cocamar",
    cocamarMembers: "15800",
    cocamarEngagement: "88",
    sicoobName: "Sicoob",
    sicoobMembers: "25300",
    sicoobEngagement: "92",
    frisiaName: "Frísia",
    frisiaMembers: "12400",
    frisiaEngagement: "85"
  });

  useEffect(() => {
    // Redirect to login if not authenticated
    if (!session?.user) {
      navigate('/login');
      return;
    }

    const loadSettings = async () => {
      try {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .maybeSingle();

        if (error) {
          console.error('Error loading settings:', error);
          toast.error("Erro ao carregar configurações");
          return;
        }

        if (profile) {
          setLogoUrl(profile.company_logo || null);
          setCompanyInfo({
            name: profile.company_name || "Cocamar",
            description: profile.company_description || "Sistema de Felicidade Interna do Cooperativismo",
            welcomeMessage: profile.welcome_message || "Bem-vindo ao Dashboard FIC! 👋",
            welcomeDescription: profile.welcome_description || "Aqui você pode acompanhar em tempo real os indicadores de felicidade e engajamento da sua cooperativa. Explore os dados e descubra insights valiosos para melhorar a experiência de todos."
          });
          setFormData({
            cocamarName: profile.cocamarname || "Cocamar",
            cocamarMembers: profile.cocamarmembers || "15800",
            cocamarEngagement: profile.cocamarengagement || "88",
            sicoobName: profile.sicoobname || "Sicoob",
            sicoobMembers: profile.sicoobmembers || "25300",
            sicoobEngagement: profile.sicoobengagement || "92",
            frisiaName: profile.frisianame || "Frísia",
            frisiaMembers: profile.frisiamembers || "12400",
            frisiaEngagement: profile.frisiaengagement || "85"
          });
        }
      } catch (error) {
        console.error('Error loading settings:', error);
        toast.error("Erro ao carregar configurações");
      }
    };

    loadSettings();
  }, [session, navigate]);

  const handleCompanyInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCompanyInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const file = e.target.files?.[0];
      if (!file) return;

      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast.error('Por favor, selecione uma imagem válida');
        return;
      }

      // Validate file size (max 2MB)
      if (file.size > 2 * 1024 * 1024) {
        toast.error('A imagem deve ter no máximo 2MB');
        return;
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${crypto.randomUUID()}.${fileExt}`;
      const filePath = `company-logos/${fileName}`;

      // Upload image to storage
      const { error: uploadError } = await supabase.storage
        .from('company-logos')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('company-logos')
        .getPublicUrl(filePath);

      setLogoUrl(publicUrl);
      toast.success('Logo atualizado com sucesso!');
    } catch (error) {
      console.error('Error uploading logo:', error);
      if (error.message?.includes('duplicate')) {
        toast.error('Erro: Nome de arquivo duplicado. Tente novamente.');
      } else if (error.message?.includes('bucket')) {
        toast.error('Erro: Bucket de armazenamento não encontrado.');
      } else {
        toast.error('Erro ao fazer upload do logo. Tente novamente.');
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session?.user) {
      toast.error("Você precisa estar logado para salvar as configurações");
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          company_name: companyInfo.name,
          company_description: companyInfo.description,
          welcome_message: companyInfo.welcomeMessage,
          welcome_description: companyInfo.welcomeDescription,
          company_logo: logoUrl,
          cocamarname: formData.cocamarName,
          cocamarmembers: formData.cocamarMembers,
          cocamarengagement: formData.cocamarEngagement,
          sicoobname: formData.sicoobName,
          sicoobmembers: formData.sicoobMembers,
          sicoobengagement: formData.sicoobEngagement,
          frisianame: formData.frisiaName,
          frisiamembers: formData.frisiaMembers,
          frisiaengagement: formData.frisiaEngagement
        })
        .eq('id', session.user.id);

      if (error) throw error;
      
      toast.success("Configurações atualizadas com sucesso!");
    } catch (error) {
      console.error(error);
      toast.error("Erro ao atualizar configurações");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Configurações do Dashboard</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-6">Informações do Dashboard</h2>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="logo">Logo da Empresa</Label>
              <div className="flex items-center gap-4">
                {logoUrl && (
                  <img
                    src={logoUrl}
                    alt="Logo da empresa"
                    className="w-16 h-16 object-contain rounded-lg border"
                  />
                )}
                <Input
                  id="logo"
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="flex-1"
                />
              </div>
              <p className="text-sm text-gray-500">
                Tamanho máximo: 2MB. Formatos aceitos: PNG, JPG, JPEG, SVG
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Nome da Empresa</Label>
              <Input
                id="name"
                name="name"
                value={companyInfo.name}
                onChange={handleCompanyInfoChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição da Empresa</Label>
              <Input
                id="description"
                name="description"
                value={companyInfo.description}
                onChange={handleCompanyInfoChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="welcomeMessage">Mensagem de Boas-vindas</Label>
              <Input
                id="welcomeMessage"
                name="welcomeMessage"
                value={companyInfo.welcomeMessage}
                onChange={handleCompanyInfoChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="welcomeDescription">Descrição da Mensagem de Boas-vindas</Label>
              <textarea
                id="welcomeDescription"
                name="welcomeDescription"
                value={companyInfo.welcomeDescription}
                onChange={handleCompanyInfoChange}
                className="w-full min-h-[100px] p-3 rounded-md border border-input"
              />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-6">Cooperativas</h2>
          
          <div className="grid gap-6">
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cocamarName">Nome da Cooperativa</Label>
                  <Input
                    id="cocamarName"
                    name="cocamarName"
                    value={formData.cocamarName}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cocamarMembers">Número de Membros</Label>
                  <Input
                    id="cocamarMembers"
                    name="cocamarMembers"
                    value={formData.cocamarMembers}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cocamarEngagement">Engajamento (%)</Label>
                  <Input
                    id="cocamarEngagement"
                    name="cocamarEngagement"
                    value={formData.cocamarEngagement}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sicoobName">Nome da Cooperativa</Label>
                  <Input
                    id="sicoobName"
                    name="sicoobName"
                    value={formData.sicoobName}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sicoobMembers">Número de Membros</Label>
                  <Input
                    id="sicoobMembers"
                    name="sicoobMembers"
                    value={formData.sicoobMembers}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sicoobEngagement">Engajamento (%)</Label>
                  <Input
                    id="sicoobEngagement"
                    name="sicoobEngagement"
                    value={formData.sicoobEngagement}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="frisiaName">Nome da Cooperativa</Label>
                  <Input
                    id="frisiaName"
                    name="frisiaName"
                    value={formData.frisiaName}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="frisiaMembers">Número de Membros</Label>
                  <Input
                    id="frisiaMembers"
                    name="frisiaMembers"
                    value={formData.frisiaMembers}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="frisiaEngagement">Engajamento (%)</Label>
                  <Input
                    id="frisiaEngagement"
                    name="frisiaEngagement"
                    value={formData.frisiaEngagement}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
            </div>
          </div>

          <Button className="mt-6" type="submit" disabled={loading}>
            {loading ? "Salvando..." : "Salvar Alterações"}
          </Button>
        </Card>
      </form>
    </div>
  );
};