import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, FileSpreadsheet, FileText, BarChart2, ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Json } from "@/integrations/supabase/types";
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface ReportMetrics {
  total_votos: number;
  pontos_fortes: number;
  desafios: number;
  oportunidades: number;
}

function isReportMetrics(metrics: Json): metrics is { [key: string]: Json } & ReportMetrics {
  if (typeof metrics !== 'object' || metrics === null || Array.isArray(metrics)) {
    return false;
  }
  
  return (
    'total_votos' in metrics &&
    'pontos_fortes' in metrics &&
    'desafios' in metrics &&
    'oportunidades' in metrics
  );
}

export default function AIReport() {
  const [selectedDimension, setSelectedDimension] = useState<string>("");
  const [analysis, setAnalysis] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [generalReport, setGeneralReport] = useState<string>("");
  const [voteSummary, setVoteSummary] = useState<any>(null);
  const [expandedSections, setExpandedSections] = useState<string[]>([]);
  const queryClient = useQueryClient();

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const deleteReportMutation = useMutation({
    mutationFn: async (reportId: string) => {
      const { error } = await supabase
        .from('fic_reports')
        .delete()
        .eq('id', reportId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ai-reports'] });
      toast.success('Relatório excluído com sucesso');
    },
    onError: () => {
      toast.error('Erro ao excluir relatório');
    }
  });

  const resetVotesMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.rpc('clean_questionnaire_votes');
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vote-details'] });
      toast.success('Votos resetados com sucesso');
    },
    onError: () => {
      toast.error('Erro ao resetar votos');
    }
  });

  const { data: dimensions, isLoading } = useQuery({
    queryKey: ['dimensions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fic_dimensions')
        .select('identifier, label');
      
      if (error) throw error;
      return data;
    },
  });

  const { data: reports, isLoading: isLoadingReports } = useQuery({
    queryKey: ['ai-reports'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fic_reports')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
  });

  // Fetch vote details
  useQuery({
    queryKey: ['vote-details'],
    queryFn: async () => {
      const { data: votes, error } = await supabase
        .from('questionnaire_votes')
        .select(`
          *,
          fic_questionnaires (
            dimension,
            strengths,
            challenges,
            opportunities
          )
        `);

      if (error) throw error;

      // Process votes to get counts and text for each option
      const summary = votes.reduce((acc: any, vote) => {
        const questionnaire = vote.fic_questionnaires;
        const type = vote.option_type;
        const number = vote.option_number;
        const key = `${type}_${number}`;

        if (!acc[type]) {
          acc[type] = {};
        }

        if (!acc[type][key]) {
          const options = questionnaire[type]?.split('\n\n') || [];
          acc[type][key] = {
            text: options[number - 1] || '',
            count: 0,
            dimension: questionnaire.dimension
          };
        }

        acc[type][key].count++;
        return acc;
      }, {});

      setVoteSummary(summary);
      return summary;
    },
  });

  // Calculate total metrics across all reports
  const totalMetrics = reports?.reduce((acc, report) => {
    if (!isReportMetrics(report.metrics)) return acc;
    return {
      total_votos: (acc.total_votos || 0) + report.metrics.total_votos,
      pontos_fortes: (acc.pontos_fortes || 0) + report.metrics.pontos_fortes,
      desafios: (acc.desafios || 0) + report.metrics.desafios,
      oportunidades: (acc.oportunidades || 0) + report.metrics.oportunidades,
    };
  }, {} as ReportMetrics) || {
    total_votos: 0,
    pontos_fortes: 0,
    desafios: 0,
    oportunidades: 0,
  };

  const generateGeneralReport = async () => {
    setIsAnalyzing(true);
    try {
      const response = await supabase.functions.invoke('analyze-vote-backups', {
        body: { 
          dimension: 'all',
          totalMetrics,
          reports: reports?.map(r => ({
            dimension: r.dimension,
            description: r.description,
            metrics: r.metrics
          }))
        },
      });

      if (response.error) throw response.error;
      setGeneralReport(response.data.analysis);
      toast.success("Relatório geral gerado com sucesso!");
    } catch (error) {
      console.error('Error:', error);
      toast.error("Erro ao gerar relatório geral");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedDimension) {
      toast.error("Por favor, selecione uma dimensão");
      return;
    }

    setIsAnalyzing(true);
    setProgress(0);
    try {
      const response = await supabase.functions.invoke('analyze-vote-backups', {
        body: { dimension: selectedDimension },
      });

      if (response.error) throw response.error;
      setAnalysis(response.data.analysis);
      setProgress(100);
      toast.success("Análise concluída com sucesso!");
    } catch (error) {
      console.error('Error:', error);
      toast.error("Erro ao gerar análise");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleExport = async (format: 'excel' | 'pdf') => {
    if (!reports || reports.length === 0) {
      toast.error("Nenhum relatório disponível para exportar");
      return;
    }

    const content = reports.map(report => {
      return {
        "Dimensão": report.dimension,
        "Título": report.title,
        "Período": `${new Date(report.start_date).toLocaleDateString('pt-BR')} até ${new Date(report.end_date).toLocaleDateString('pt-BR')}`,
        "Total de Votos": report.metrics.total_votos,
        "Pontos Fortes": report.metrics.pontos_fortes,
        "Desafios": report.metrics.desafios,
        "Oportunidades": report.metrics.oportunidades,
        "Análise Completa": report.description
      };
    }).filter(Boolean);

    if (format === 'excel') {
      // Configure column widths
      const ws = XLSX.utils.json_to_sheet(content, {
        header: [
          "Dimensão",
          "Título",
          "Período",
          "Total de Votos",
          "Pontos Fortes",
          "Desafios",
          "Oportunidades",
          "Análise Completa"
        ]
      });

      // Set column widths
      ws['!cols'] = [
        { wch: 15 }, // Dimensão
        { wch: 30 }, // Título
        { wch: 25 }, // Período
        { wch: 15 }, // Total de Votos
        { wch: 15 }, // Pontos Fortes
        { wch: 15 }, // Desafios
        { wch: 15 }, // Oportunidades
        { wch: 100 }, // Análise Completa
      ];

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Relatório");
      XLSX.writeFile(wb, "relatorio_ia.xlsx");
      toast.success('Relatório Excel exportado com sucesso!');
    } else if (format === 'pdf') {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 14;
      const contentWidth = pageWidth - 2 * margin;
      
      // Add title
      doc.setFontSize(16);
      doc.text("Relatório de Análise IA", margin, 15);
      
      // Add date
      doc.setFontSize(10);
      doc.text(`Gerado em: ${new Date().toLocaleDateString('pt-BR')}`, margin, 25);
      
      let yPos = 35;
      
      // Add each report
      content.forEach((report, index) => {
        if (yPos > doc.internal.pageSize.getHeight() - 20) {
          doc.addPage();
          yPos = 20;
        }

        // Add report header
        doc.setFontSize(14);
        doc.setTextColor(0, 0, 0);
        doc.text(`Relatório ${index + 1}: ${report["Dimensão"]}`, margin, yPos);
        yPos += 10;

        // Add metadata table
        autoTable(doc, {
          head: [['Métrica', 'Valor']],
          body: [
            ['Período', report["Período"]],
            ['Total de Votos', report["Total de Votos"].toString()],
            ['Pontos Fortes', report["Pontos Fortes"].toString()],
            ['Desafios', report["Desafios"].toString()],
            ['Oportunidades', report["Oportunidades"].toString()],
          ],
          startY: yPos,
          margin: { left: margin },
          theme: 'grid',
          styles: { fontSize: 10 },
          columnStyles: {
            0: { cellWidth: 40 },
            1: { cellWidth: 60 }
          }
        });

        yPos = (doc as any).lastAutoTable.finalY + 10;

        // Add analysis title
        doc.setFontSize(12);
        doc.text("Análise Detalhada:", margin, yPos);
        yPos += 7;

        // Add analysis content with word wrap
        doc.setFontSize(10);
        const splitText = doc.splitTextToSize(report["Análise Completa"], contentWidth);
        
        splitText.forEach((line: string) => {
          if (yPos > doc.internal.pageSize.getHeight() - 20) {
            doc.addPage();
            yPos = 20;
          }
          doc.text(line, margin, yPos);
          yPos += 5;
        });

        // Add spacing between reports
        yPos += 15;

        // Add page break if not the last report
        if (index < content.length - 1) {
          doc.addPage();
          yPos = 20;
        }
      });
      
      doc.save('relatorio_ia.pdf');
      toast.success('Relatório PDF exportado com sucesso!');
    }
  };

  return (
    <div className="space-y-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Relatório IA</h1>
        <p className="text-gray-500 mt-2">
          Análise detalhada dos votos por dimensão usando inteligência artificial
        </p>
      </div>

      <Card className="p-6">
        {/* Summary Metrics Card */}
        <div className="mb-8 bg-gray-50 p-6 rounded-lg">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-semibold flex items-center gap-2">
            <BarChart2 className="h-5 w-5 text-primary" />
            Total de Votos
            <span className="text-sm font-normal text-gray-500 ml-2">
              (Total de {totalMetrics.total_votos} votos registrados)
            </span>
            </h3>
            <select
              className="p-2 border rounded-md"
              value={selectedDimension}
              onChange={(e) => setSelectedDimension(e.target.value)}
            >
              <option value="">Todas as dimensões</option>
              {dimensions?.map((dimension) => (
                <option key={dimension.identifier} value={dimension.identifier}>
                  {dimension.label}
                </option>
              ))}
            </select>
          </div>
          
          {voteSummary && (
            <div className="space-y-6">
              {/* Pontos Fortes Section */}
              <div className="bg-white p-6 rounded-lg shadow">
                <button
                  onClick={() => toggleSection('strengths')}
                  className="w-full flex justify-between items-center text-lg font-semibold text-green-600 mb-4"
                >
                  <span>Pontos Fortes ({totalMetrics.pontos_fortes} votos)</span>
                  {expandedSections.includes('strengths') ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </button>
                <div className={`space-y-3 ${expandedSections.includes('strengths') ? '' : 'hidden'}`}>
                  {Object.entries(voteSummary.strengths || {}).sort((a: any, b: any) => b[1].count - a[1].count).map(([key, data]: [string, any]) => (
                    (!selectedDimension || data.dimension === selectedDimension) && (
                    <div key={key} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{data.text}</p>
                        <p className="text-xs text-gray-500">Dimensão: {data.dimension}</p>
                      </div>
                      <div className="ml-4 text-right">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 gap-1">
                          <span>{data.count}</span>
                          <span>votos</span>
                        </span>
                      </div>
                    </div>
                    )
                  ))}
                </div>
              </div>

              {/* Desafios Section */}
              <div className="bg-white p-6 rounded-lg shadow">
                <button
                  onClick={() => toggleSection('challenges')}
                  className="w-full flex justify-between items-center text-lg font-semibold text-yellow-600 mb-4"
                >
                  <span>Desafios ({totalMetrics.desafios} votos)</span>
                  {expandedSections.includes('challenges') ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </button>
                <div className={`space-y-3 ${expandedSections.includes('challenges') ? '' : 'hidden'}`}>
                  {Object.entries(voteSummary.challenges || {}).sort((a: any, b: any) => b[1].count - a[1].count).map(([key, data]: [string, any]) => (
                    (!selectedDimension || data.dimension === selectedDimension) && (
                    <div key={key} className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{data.text}</p>
                        <p className="text-xs text-gray-500">Dimensão: {data.dimension}</p>
                      </div>
                      <div className="ml-4 text-right">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 gap-1">
                          <span>{data.count}</span>
                          <span>votos</span>
                        </span>
                      </div>
                    </div>
                    )
                  ))}
                </div>
              </div>

              {/* Oportunidades Section */}
              <div className="bg-white p-6 rounded-lg shadow">
                <button
                  onClick={() => toggleSection('opportunities')}
                  className="w-full flex justify-between items-center text-lg font-semibold text-blue-600 mb-4"
                >
                  <span>Oportunidades ({totalMetrics.oportunidades} votos)</span>
                  {expandedSections.includes('opportunities') ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </button>
                <div className={`space-y-3 ${expandedSections.includes('opportunities') ? '' : 'hidden'}`}>
                  {Object.entries(voteSummary.opportunities || {}).sort((a: any, b: any) => b[1].count - a[1].count).map(([key, data]: [string, any]) => (
                    (!selectedDimension || data.dimension === selectedDimension) && (
                    <div key={key} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{data.text}</p>
                        <p className="text-xs text-gray-500">Dimensão: {data.dimension}</p>
                      </div>
                      <div className="ml-4 text-right">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 gap-1">
                          <span>{data.count}</span>
                          <span>votos</span>
                        </span>
                      </div>
                    </div>
                    )
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Selecione a Dimensão
            </label>
            <select
              className="w-full p-2 border rounded-md"
              value={selectedDimension}
              onChange={(e) => setSelectedDimension(e.target.value)}
            >
              <option value="">Selecione uma dimensão...</option>
              {dimensions?.map((dimension) => (
                <option key={dimension.identifier} value={dimension.identifier}>
                  {dimension.label}
                </option>
              ))}
            </select>
          </div>

          <Button
            onClick={handleAnalyze}
            disabled={isAnalyzing || !selectedDimension}
            className="w-full"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analisando...
              </>
            ) : (
              'Gerar Análise'
            )}
          </Button>

          {isAnalyzing && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Gerando relatório...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
          )}
        </div>

        {reports && reports.length > 0 && (
          <div className="mt-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Relatórios Gerados</h2>
              <div className="flex gap-2">
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Resetar Votos
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Resetar todos os votos?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Esta ação irá remover todos os votos registrados. Esta ação não pode ser desfeita.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={() => resetVotesMutation.mutateAsync()}>
                        Confirmar
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport('excel')}
                >
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  Excel
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleExport('pdf')}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  PDF
                </Button>
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Dimensão</TableHead>
                    <TableHead>Total de Votos</TableHead>
                    <TableHead>Pontos Fortes</TableHead>
                    <TableHead>Desafios</TableHead>
                    <TableHead>Oportunidades</TableHead>
                    <TableHead>Data Início</TableHead>
                    <TableHead>Data Fim</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reports.map((report) => {
                    const metrics = report.metrics;
                    if (!isReportMetrics(metrics)) {
                      console.error('Invalid metrics format:', metrics);
                      return null;
                    }
                    
                    return (
                      <TableRow key={report.id}>
                        <TableCell>{report.dimension}</TableCell>
                        <TableCell>{metrics.total_votos}</TableCell>
                        <TableCell>{metrics.pontos_fortes}</TableCell>
                        <TableCell>{metrics.desafios}</TableCell>
                        <TableCell>{metrics.oportunidades}</TableCell>
                        <TableCell>
                          {new Date(report.start_date).toLocaleDateString('pt-BR')}
                        </TableCell>
                        <TableCell>
                          {new Date(report.end_date).toLocaleDateString('pt-BR')}
                        </TableCell>
                        <TableCell>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Excluir relatório?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Esta ação não pode ser desfeita.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                <AlertDialogAction onClick={() => deleteReportMutation.mutateAsync(report.id)}>
                                  Confirmar
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
        )}

        {generalReport && (
          <div className="mt-6 prose max-w-none bg-white p-6 rounded-lg border">
            <h3 className="text-xl font-semibold mb-4">Relatório Geral</h3>
            <div className="whitespace-pre-wrap">{generalReport}</div>
          </div>
        )}

        {analysis && (
          <div className="mt-6 prose max-w-none">
            <div className="whitespace-pre-wrap">{analysis}</div>
          </div>
        )}
      </Card>
    </div>
  );
}