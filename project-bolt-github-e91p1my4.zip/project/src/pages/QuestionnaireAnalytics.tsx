import { AnalyticsContainer } from "@/components/analytics/AnalyticsContainer";

const QuestionnaireAnalytics = () => {
  return (
    <div className="p-6">
      <AnalyticsContainer />
    </div>
  );
};

export default QuestionnaireAnalytics;