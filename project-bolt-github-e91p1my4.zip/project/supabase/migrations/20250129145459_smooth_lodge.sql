/*
  # Add Company Info Columns to Profiles Table

  1. Changes
    - Add company_name column
    - Add company_description column
    - Add welcome_message column
    - Add welcome_description column
    - Add company_logo column

  2. Security
    - No changes to RLS policies needed
    - Existing profile access controls remain in place
*/

DO $$ BEGIN
  -- Add company_name column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'company_name'
  ) THEN
    ALTER TABLE profiles ADD COLUMN company_name text;
  END IF;

  -- Add company_description column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'company_description'
  ) THEN
    ALTER TABLE profiles ADD COLUMN company_description text;
  END IF;

  -- Add welcome_message column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'welcome_message'
  ) THEN
    ALTER TABLE profiles ADD COLUMN welcome_message text;
  END IF;

  -- Add welcome_description column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'welcome_description'
  ) THEN
    ALTER TABLE profiles ADD COLUMN welcome_description text;
  END IF;

  -- Add company_logo column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'company_logo'
  ) THEN
    ALTER TABLE profiles ADD COLUMN company_logo text;
  END IF;
END $$;