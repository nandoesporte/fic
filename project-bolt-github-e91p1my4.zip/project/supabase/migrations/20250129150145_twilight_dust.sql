/*
  # Create storage bucket and policies for company logos

  1. Storage
    - Create 'company-logos' bucket for storing company logos
    - Set bucket to public access
  
  2. Security
    - Enable RLS on storage.objects
    - Add policies for authenticated users to manage their company logos
    - Add policy for public read access to logos
*/

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('company-logos', 'company-logos', true);

-- Enable RLS
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users to upload/update logos
CREATE POLICY "Users can upload company logos"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'company-logos' AND
  (storage.foldername(name))[1] = 'company-logos'
);

-- Policy for authenticated users to update their logos
CREATE POLICY "Users can update their company logos"
ON storage.objects FOR UPDATE TO authenticated
USING (
  bucket_id = 'company-logos' AND
  (storage.foldername(name))[1] = 'company-logos'
);

-- Policy for public read access to logos
CREATE POLICY "Public read access for company logos"
ON storage.objects FOR SELECT TO public
USING (bucket_id = 'company-logos');

-- Policy for authenticated users to delete their logos
CREATE POLICY "Users can delete their company logos"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'company-logos' AND
  (storage.foldername(name))[1] = 'company-logos'
);